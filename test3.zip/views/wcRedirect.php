<?php

$room = $_GET["name"];
header("Location: https://appr.tc/r/" . $room);

?>